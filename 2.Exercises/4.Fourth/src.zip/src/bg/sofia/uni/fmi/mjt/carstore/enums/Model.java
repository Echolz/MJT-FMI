package bg.sofia.uni.fmi.mjt.carstore.enums;

public enum Model {
    ALFA_ROMEO, AUDI, BMW, MERCEDES, FERRARI, OPEL;
}
