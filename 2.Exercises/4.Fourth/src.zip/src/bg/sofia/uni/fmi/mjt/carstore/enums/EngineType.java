package bg.sofia.uni.fmi.mjt.carstore.enums;

public enum EngineType {
    DIESEL, GASOLINE, ELECTRIC, HYBRID;
}
